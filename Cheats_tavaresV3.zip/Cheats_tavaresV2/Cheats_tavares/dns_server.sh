#!/bin/bash

nome=$(hostname)
read -p "Introduza o seu nome " nom
read -p "Introduza o dominio " dom

dominio="${nome}.${dom}."
rd="root.${nome}.${dom}."
read -p "Introduza o IP desta máquina " ip
IFS='.' read -r o1 o2 o3 o4 <<< "$ip"

reverse_zone="${o3}.${o2}.${o1}.in-addr.arpa"
ptr="$o4"

read -p "Introduza a porta do ssh " porta
read -p "Introduza a maxtries do ssh " maxtries


echo "

         ██████╗██╗  ██╗███████╗ █████╗ ████████╗███████╗    ████████╗ █████╗ ██╗   ██╗ █████╗ ██████╗ ███████╗███████╗
        ██╔════╝██║  ██║██╔════╝██╔══██╗╚══██╔══╝██╔════╝    ╚══██╔══╝██╔══██╗██║   ██║██╔══██╗██╔══██╗██╔════╝██╔════╝
        ██║     ███████║█████╗  ███████║   ██║   ███████╗       ██║   ███████║██║   ██║███████║██████╔╝█████╗  ███████╗
        ██║     ██╔══██║██╔══╝  ██╔══██║   ██║   ╚════██║       ██║   ██╔══██║╚██╗ ██╔╝██╔══██║██╔══██╗██╔══╝  ╚════██║
        ╚██████╗██║  ██║███████╗██║  ██║   ██║   ███████║       ██║   ██║  ██║ ╚████╔╝ ██║  ██║██║  ██║███████╗███████║
         ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝       ╚═╝   ╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝
                                                                                                               
"
ip link set ens37 down
export http_proxy=http://172.18.3.12:8080
export https_proxy=http://172.18.3.12:8080

apt-get update -y
apt-get upgrade -y
apt-get install -y net-tools apache2 openssh-server bind9


echo "$nom" > /etc/issue.net
echo "$nom" > /etc/motd

echo "Port $porta" >> /etc/ssh/sshd_config
echo "MaxAuthTries $maxtries" >> /etc/ssh/sshd_config
echo "Banner /etc/issue.net" >> /etc/ssh/sshd_config


systemctl restart ssh

ufw enable
ufw allow 80/tcp
ufw allow $porta/tcp
ufw allow 53/tcp
ufw allow 53/udp


mkdir -p /etc/bind/zones

cat << EOF >> /etc/bind/named.conf.local
zone "tiigr.pt" IN {
    type master;
    file "/etc/bind/zones/forward.tiigr.pt";
};

zone "$reverse_zone" IN {
    type master;
    file "/etc/bind/zones/reverse.tiigr.pt";
};
EOF

cat << EOF > /etc/bind/zones/forward.tiigr.pt
\$TTL 8600
@   IN  SOA $dominio $rd (
        1       ; Serial
        604800  ; Refresh
        86400   ; Retry
        2419200 ; Expire
        86400 ) ; Negative Cache TTL

@   IN  NS $nome.
@   IN  A $ip
apache  IN  A $ip
ssh     IN  A $ip
EOF

cat << EOF > /etc/bind/zones/reverse.tiigr.pt
\$TTL 8600
@   IN  SOA $dominio $rd (
        1
        604800
        86400
        2419200
        86400 )

@   IN  NS $nome.
$ptr IN  PTR $nome.
EOF

systemctl restart bind9

clear 



ip link set ens37 up
echo "Cheat finalizado"
