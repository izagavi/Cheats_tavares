#!/bin/bash

host=$(hostname)

read -p "Introduza a subnet do dhcp " subnet

read -p "Introduza a netmask " netmask

read -p "Introduza o IP do router " router

read -p "Introduza o primeiro IP da range " r1

read -p "Introduza o ultimo IP da range " r2

read -p "Introduza o dominio " dom

read -p "Introduza o IP do server dns " dnsIP

read -p "Introduza o IP de broadcast " br


echo "

         ██████╗██╗  ██╗███████╗ █████╗ ████████╗███████╗    ████████╗ █████╗ ██╗   ██╗ █████╗ ██████╗ ███████╗███████╗
        ██╔════╝██║  ██║██╔════╝██╔══██╗╚══██╔══╝██╔════╝    ╚══██╔══╝██╔══██╗██║   ██║██╔══██╗██╔══██╗██╔════╝██╔════╝
        ██║     ███████║█████╗  ███████║   ██║   ███████╗       ██║   ███████║██║   ██║███████║██████╔╝█████╗  ███████╗
        ██║     ██╔══██║██╔══╝  ██╔══██║   ██║   ╚════██║       ██║   ██╔══██║╚██╗ ██╔╝██╔══██║██╔══██╗██╔══╝  ╚════██║
        ╚██████╗██║  ██║███████╗██║  ██║   ██║   ███████║       ██║   ██║  ██║ ╚████╔╝ ██║  ██║██║  ██║███████╗███████║
         ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝       ╚═╝   ╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝
                                                                                                         
"

ip link set ens37 down

export http_proxy=http://172.18.3.12:8080
export https_proxy=http://172.18.3.12:8080

apt-get update -y

apt-get upgrade -y

apt install net-tools -y

apt install isc-dhcp-server -y


cat << EOF > /etc/default/isc-dhcp-server
INTERFACESv4="ens37"
INTERFACESv6=""

EOF



cat << EOF > /etc/dhcp/dhcpd.conf
option domain-name "$dom";
option domain-name-servers $host.$dom;

default-lease-time 600;
max-lease-time 7200;

ddns-update-style none;

subnet $subnet netmask $netmask {
range $r1 $r2;
option routers $router;
option domain-name "$dom"; 
option domain-name-servers $dnsIP;
option broadcast-address $br;
option subnet-mask $netmask;
}
EOF

systemctl restart isc-dhcp-server
systemctl start isc-dhcp-server

ufw enable
ufw allow 67/udp


ip link set ens37 up
echo "Script finalizado"